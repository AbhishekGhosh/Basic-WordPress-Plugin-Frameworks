<?php

function complexplguin_admin_sub_page_init(){

        echo "<h1>Complex Plugin Sub Level Menu Example</h1>";

} 

// php is better not to close ?>