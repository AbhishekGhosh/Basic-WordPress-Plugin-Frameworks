<?php

function complexplguin_admin_page_init(){

        echo "<h1>Complex Top Level Menu Example</h1>";

} 

// php is better not to close ?>