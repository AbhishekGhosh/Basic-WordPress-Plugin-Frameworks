<?php

/**
 * Plugin Name: Basic Plugin
 * Plugin URI: https://thecustomizewindows.com/2015/05/create-wordpress-plugin-to-avoid-snippets-on-themes-functions-php/
 * Description: Basic plugin to add snippets
 * Author: Abhishek Ghosh
 * Author URI: https://thecustomizewindows.com
 * Version: 2.0
 */
 
// add snippets here
// basic plugin


// php better not to close unless needed ?>